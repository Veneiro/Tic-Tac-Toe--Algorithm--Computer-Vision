#pragma once

#include <Arduino.h>

void robotServiceInit();
void robotServiceResetPieces();
bool robotServiceMoveToCell(int fila, int columna);
